create trigger TU_PLACE
    after update
    on PLACE
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* erwin Builtin Trigger */
  /* Place  Artwork on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="0002eecf", PARENT_OWNER="", PARENT_TABLE="Place"
    CHILD_OWNER="", CHILD_TABLE="Artwork"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_27", FK_COLUMNS="Place_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Place_ID <> :new.Place_ID
  THEN
    SELECT count(*) INTO NUMROWS
      FROM Artwork
      WHERE
        /*  %JoinFKPK(Artwork,:%Old," = "," AND") */
        Artwork.Place_ID = :old.Place_ID;
    IF (NUMROWS > 0)
    THEN 
      raise_application_error(
        -20005,
        'Cannot update Place because Artwork exists.'
      );
    END IF;
  END IF;

  /* erwin Builtin Trigger */
  /* Place  Exhibition on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Place"
    CHILD_OWNER="", CHILD_TABLE="Exhibition"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_20", FK_COLUMNS="Place_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Place_ID <> :new.Place_ID
  THEN
    SELECT count(*) INTO NUMROWS
      FROM Exhibition
      WHERE
        /*  %JoinFKPK(Exhibition,:%Old," = "," AND") */
        Exhibition.Place_ID = :old.Place_ID;
    IF (NUMROWS > 0)
    THEN 
      raise_application_error(
        -20005,
        'Cannot update Place because Exhibition exists.'
      );
    END IF;
  END IF;

  /* erwin Builtin Trigger */
  /* City  Place on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="City"
    CHILD_OWNER="", CHILD_TABLE="Place"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_29", FK_COLUMNS="City_ID" */
  SELECT count(*) INTO NUMROWS
    FROM City
    WHERE
      /* %JoinFKPK(:%New,City," = "," AND") */
      :new.City_ID = City.City_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Place because City does not exist.'
    );
  END IF;


-- erwin Builtin Trigger
END;
/

