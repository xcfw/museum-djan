create trigger TU_PARTICIPANTS
    after update
    on PARTICIPANTS
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* erwin Builtin Trigger */
  /* Artist  Participants on child update no action */
  /* ERWIN_RELATION:CHECKSUM="0002078a", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_57", FK_COLUMNS="Artist_ID" */
  SELECT count(*) INTO NUMROWS
    FROM Artist
    WHERE
      /* %JoinFKPK(:%New,Artist," = "," AND") */
      :new.Artist_ID = Artist.Artist_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    :new.Artist_ID IS NOT NULL AND
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Participants because Artist does not exist.'
    );
  END IF;

  /* erwin Builtin Trigger */
  /* Exhibition  Participants on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Exhibition"
    CHILD_OWNER="", CHILD_TABLE="Participants"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_18", FK_COLUMNS="Exhibition_ID" */
  SELECT count(*) INTO NUMROWS
    FROM Exhibition
    WHERE
      /* %JoinFKPK(:%New,Exhibition," = "," AND") */
      :new.Exhibition_ID = Exhibition.Exhibition_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Participants because Exhibition does not exist.'
    );
  END IF;


-- erwin Builtin Trigger
END;
/

