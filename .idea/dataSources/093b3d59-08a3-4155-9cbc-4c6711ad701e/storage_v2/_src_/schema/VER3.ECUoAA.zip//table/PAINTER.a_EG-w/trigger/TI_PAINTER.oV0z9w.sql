create trigger TI_PAINTER
    before insert
    on PAINTER
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Artist  Painter on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="0001e292", PARENT_OWNER="", PARENT_TABLE="Artist"
    CHILD_OWNER="", CHILD_TABLE="Painter"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_60", FK_COLUMNS="Artist_ID" */
    UPDATE Painter
      SET
        /* %SetFK(Painter,NULL) */
        Painter.Artist_ID = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM Artist
            WHERE
              /* %JoinFKPK(:%New,Artist," = "," AND") */
              :new.Artist_ID = Artist.Artist_ID
        ) 
        /* %JoinPKPK(Painter,:%New," = "," AND") */
         and Painter.Painter_ID = :new.Painter_ID;

    /* erwin Builtin Trigger */
    /* Paint_Types  Painter on child insert set null */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Paint_Types"
    CHILD_OWNER="", CHILD_TABLE="Painter"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_39", FK_COLUMNS="PaintType_ID" */
    UPDATE Painter
      SET
        /* %SetFK(Painter,NULL) */
        Painter.PaintType_ID = NULL
      WHERE
        NOT EXISTS (
          SELECT * FROM Paint_Types
            WHERE
              /* %JoinFKPK(:%New,Paint_Types," = "," AND") */
              :new.PaintType_ID = Paint_Types.PaintType_ID
        ) 
        /* %JoinPKPK(Painter,:%New," = "," AND") */
         and Painter.Painter_ID = :new.Painter_ID;


-- erwin Builtin Trigger
END;
/

