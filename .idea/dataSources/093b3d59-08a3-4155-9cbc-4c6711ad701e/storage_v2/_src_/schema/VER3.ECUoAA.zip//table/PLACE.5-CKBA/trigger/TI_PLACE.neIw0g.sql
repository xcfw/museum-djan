create trigger TI_PLACE
    before insert
    on PLACE
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* City  Place on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="0000e164", PARENT_OWNER="", PARENT_TABLE="City"
    CHILD_OWNER="", CHILD_TABLE="Place"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_29", FK_COLUMNS="City_ID" */
    SELECT count(*) INTO NUMROWS
      FROM City
      WHERE
        /* %JoinFKPK(:%New,City," = "," AND") */
        :new.City_ID = City.City_ID;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */
      
      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert Place because City does not exist.'
      );
    END IF;


-- erwin Builtin Trigger
END;
/

