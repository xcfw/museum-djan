create trigger TU_ARTWORK
    after update
    on ARTWORK
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* Artwork  Rarity on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="0001c76c", PARENT_OWNER="", PARENT_TABLE="Artwork"
    CHILD_OWNER="", CHILD_TABLE="Rarity"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_40", FK_COLUMNS="Artwork_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.Artwork_ID <> :new.Artwork_ID
  THEN
    UPDATE Rarity
      SET
        /* %SetFK(Rarity,NULL) */
        Rarity.Artwork_ID = NULL
      WHERE
        /* %JoinFKPK(Rarity,:%Old," = ",",") */
        Rarity.Artwork_ID = :old.Artwork_ID;
  END IF;

  /* erwin Builtin Trigger */
  /* Place  Artwork on child update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Place"
    CHILD_OWNER="", CHILD_TABLE="Artwork"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_27", FK_COLUMNS="Place_ID" */
  SELECT count(*) INTO NUMROWS
    FROM Place
    WHERE
      /* %JoinFKPK(:%New,Place," = "," AND") */
      :new.Place_ID = Place.Place_ID;
  IF (
    /* %NotnullFK(:%New," IS NOT NULL AND") */
    
    NUMROWS = 0
  )
  THEN
    raise_application_error(
      -20007,
      'Cannot update Artwork because Place does not exist.'
    );
  END IF;


-- erwin Builtin Trigger
END;
/

