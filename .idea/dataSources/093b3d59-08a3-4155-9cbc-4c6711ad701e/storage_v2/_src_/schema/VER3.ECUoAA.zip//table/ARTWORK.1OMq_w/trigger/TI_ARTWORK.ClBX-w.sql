create trigger TI_ARTWORK
    before insert
    on ARTWORK
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Place  Artwork on child insert restrict */
    /* ERWIN_RELATION:CHECKSUM="0000d7c2", PARENT_OWNER="", PARENT_TABLE="Place"
    CHILD_OWNER="", CHILD_TABLE="Artwork"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_27", FK_COLUMNS="Place_ID" */
    SELECT count(*) INTO NUMROWS
      FROM Place
      WHERE
        /* %JoinFKPK(:%New,Place," = "," AND") */
        :new.Place_ID = Place.Place_ID;
    IF (
      /* %NotnullFK(:%New," IS NOT NULL AND") */
      
      NUMROWS = 0
    )
    THEN
      raise_application_error(
        -20002,
        'Cannot insert Artwork because Place does not exist.'
      );
    END IF;


-- erwin Builtin Trigger
END;
/

