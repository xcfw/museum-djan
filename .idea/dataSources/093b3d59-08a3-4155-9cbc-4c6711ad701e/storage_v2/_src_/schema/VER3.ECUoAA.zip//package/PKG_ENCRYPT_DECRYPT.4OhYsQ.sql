create package pkg_encrypt_decrypt

   as

   function enc_account_passwd(

   p_account_passwd in varchar2,

   p_account_name in varchar2,

   p_unlock_code in varchar2 default null)

   return varchar2;



   function dec_account_passwd(

   p_account_passwd in varchar2,

   p_account_name in varchar2,

   p_unlock_code in varchar2 default null)

   return varchar2;

end;
/

