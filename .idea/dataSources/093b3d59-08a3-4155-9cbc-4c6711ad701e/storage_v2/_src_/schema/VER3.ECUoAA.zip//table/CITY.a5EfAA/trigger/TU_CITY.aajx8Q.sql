create trigger TU_CITY
    after update
    on CITY
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
  /* City  Artist on parent update set null */
  /* ERWIN_RELATION:CHECKSUM="0001d298", PARENT_OWNER="", PARENT_TABLE="City"
    CHILD_OWNER="", CHILD_TABLE="Artist"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_56", FK_COLUMNS="City_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.City_ID <> :new.City_ID
  THEN
    UPDATE Artist
      SET
        /* %SetFK(Artist,NULL) */
        Artist.City_ID = NULL
      WHERE
        /* %JoinFKPK(Artist,:%Old," = ",",") */
        Artist.City_ID = :old.City_ID;
  END IF;

  /* erwin Builtin Trigger */
  /* City  Place on parent update restrict */
  /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="City"
    CHILD_OWNER="", CHILD_TABLE="Place"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_29", FK_COLUMNS="City_ID" */
  IF
    /* %JoinPKPK(:%Old,:%New," <> "," OR ") */
    :old.City_ID <> :new.City_ID
  THEN
    SELECT count(*) INTO NUMROWS
      FROM Place
      WHERE
        /*  %JoinFKPK(Place,:%Old," = "," AND") */
        Place.City_ID = :old.City_ID;
    IF (NUMROWS > 0)
    THEN 
      raise_application_error(
        -20005,
        'Cannot update City because Place exists.'
      );
    END IF;
  END IF;


-- erwin Builtin Trigger
END;
/

