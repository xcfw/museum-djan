create trigger TD_PAINT_TYPES
    after delete
    on PAINT_TYPES
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Paint_Types  Painter on parent delete set null */
    /* ERWIN_RELATION:CHECKSUM="0000bb3d", PARENT_OWNER="", PARENT_TABLE="Paint_Types"
    CHILD_OWNER="", CHILD_TABLE="Painter"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_39", FK_COLUMNS="PaintType_ID" */
    UPDATE Painter
      SET
        /* %SetFK(Painter,NULL) */
        Painter.PaintType_ID = NULL
      WHERE
        /* %JoinFKPK(Painter,:%Old," = "," AND") */
        Painter.PaintType_ID = :old.PaintType_ID;


-- erwin Builtin Trigger
END;
/

