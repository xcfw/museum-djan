create trigger TD_PLACE
    after delete
    on PLACE
    for each row
DECLARE NUMROWS INTEGER;
BEGIN
    /* erwin Builtin Trigger */
    /* Place  Artwork on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="0001b75f", PARENT_OWNER="", PARENT_TABLE="Place"
    CHILD_OWNER="", CHILD_TABLE="Artwork"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_27", FK_COLUMNS="Place_ID" */
    SELECT count(*) INTO NUMROWS
      FROM Artwork
      WHERE
        /*  %JoinFKPK(Artwork,:%Old," = "," AND") */
        Artwork.Place_ID = :old.Place_ID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete Place because Artwork exists.'
      );
    END IF;

    /* erwin Builtin Trigger */
    /* Place  Exhibition on parent delete restrict */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Place"
    CHILD_OWNER="", CHILD_TABLE="Exhibition"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="", 
    FK_CONSTRAINT="R_20", FK_COLUMNS="Place_ID" */
    SELECT count(*) INTO NUMROWS
      FROM Exhibition
      WHERE
        /*  %JoinFKPK(Exhibition,:%Old," = "," AND") */
        Exhibition.Place_ID = :old.Place_ID;
    IF (NUMROWS > 0)
    THEN
      raise_application_error(
        -20001,
        'Cannot delete Place because Exhibition exists.'
      );
    END IF;


-- erwin Builtin Trigger
END;
/

